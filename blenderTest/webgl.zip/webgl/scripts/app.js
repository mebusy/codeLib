
			var scene = new THREE.Scene();
			// var camera = new THREE.PerspectiveCamera( 75, window.innerWidth/window.innerHeight, 0.1, 1000 );

			var renderer = new THREE.WebGLRenderer(  );
			renderer.setSize( window.innerWidth, window.innerHeight );
			document.body.appendChild( renderer.domElement );

            // keep same looking as rendered by default blender
            renderer.setClearColor( 0x464646 );
            renderer.physicallyCorrectLights = true ; 
            var light = new THREE.AmbientLight( 0x464646 ); // soft white light
            scene.add( light );
            renderer.gammaOutput = true

            var camera ; 
            var loader = new THREE.GLTFLoader();
            loader.load( 'http://localhost:8000/assets/mill_28_sep.gltf', function ( gltf ) {
                    
                gltf.scene.traverse( function ( child ) {
                    if ( child instanceof THREE.Mesh ) {
                        console.log( child.material )
                    }
                } );


                camera = gltf.cameras[0] ;
                scene.add( gltf.scene );

                // console.log( gltf )


                // outlining 
                renderer.shadowMap.enabled = true;
                composer = new THREE.EffectComposer( renderer );
                composer.setSize( window.innerWidth, window.innerHeight );
                var renderPass = new THREE.RenderPass( scene, camera );
                composer.addPass( renderPass );
                //*
                outlinePass = new THREE.OutlinePass( new THREE.Vector2( window.innerWidth, window.innerHeight ), scene, camera );
                composer.addPass( outlinePass );
                outlinePass.selectedObjects = gltf.scene.children.slice(4)
                outlinePass.visibleEdgeColor = new THREE.Color( 0xF00000 );
                outlinePass.hiddenEdgeColor = new THREE.Color( 0x000000 );
                /*/

                //*/

                // for ( k in outlinePass ) {
                //     console.log( k  )
                // }

                //*
                var animate = function () {
                    requestAnimationFrame( animate );

                    // gltf.scene.rotation.x += 0.01;
                    // gltf.scene.rotation.y += 0.01;
                    // gltf.scene.rotation.y += 0.01;

                    // renderer.render( scene, camera );
                    composer.render()
                };

                animate();
                //*/
            }, undefined, function ( error ) {

                console.error( error );

            } );


